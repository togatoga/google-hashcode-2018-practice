#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define rep(i,n) for(ll i=0;i<(ll)(n);i++)
#define rep1(i,n) for(ll i=1;i<=(ll)(n);i++)

#define LOCAL 1;
#ifdef LOCAL
#define dbg(x) cerr << __LINE__ << " : " << #x << " = " << (x) << endl
#else
#define dbg(x) true
#endif

template<typename T>
ostream& operator<< (ostream& out, const vector<T>& v) {
  out << "[";
  size_t last = v.size() - 1;
  for (size_t i = 0; i < v.size(); ++i) {
    out << v[i];
    if (i != last)
      out << ", ";
  }
  out << "]";
  return out;
}

template<typename F, typename S>
ostream& operator<< (ostream& out, const pair<F,S>& p) {
  out << "[" << p.first << ", " << p.second << "]";
  return out;
}

int main(){
  ios::sync_with_stdio(false);
  cin.tie(0);

  ll m;
  vector<ll> team(3);
  cin  >> m;
  rep(i,3) cin >> team[i];
  map<string,ll> mp;
  map<ll,string> mp_inv;
  vector<vector<ll>> pizza(m,vector<ll>());
  ll ing_idx=0;
  rep(i,m){
    int l;
    cin >> l;
    rep(j,l){
      string s;
      cin >> s;
      if(!mp.count(s)){
        mp[s]=ing_idx;
        mp_inv[ing_idx]=s;
        ing_idx++;
      }
      pizza[i].push_back(mp[s]);
    }
  }

  


  return 0;
    

}
